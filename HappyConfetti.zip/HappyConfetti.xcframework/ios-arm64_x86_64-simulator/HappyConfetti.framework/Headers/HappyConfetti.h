//
//  HappyConfetti.h
//  HappyConfetti
//
//  Created by Sasa Jovanovic on 6.6.24..
//

#import <Foundation/Foundation.h>

//! Project version number for HappyConfetti.
FOUNDATION_EXPORT double HappyConfettiVersionNumber;

//! Project version string for HappyConfetti.
FOUNDATION_EXPORT const unsigned char HappyConfettiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HappyConfetti/PublicHeader.h>


